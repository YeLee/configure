#include <windows.h>

BOOL CheckPe(char FileName[MAX_PATH])
{

	HANDLE hFile=CreateFile(FileName,GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
	if(INVALID_HANDLE_VALUE==hFile)
	{
		return FALSE;
	}

	IMAGE_DOS_HEADER image_dos_header;
	IMAGE_NT_HEADERS image_nt_headers;

	BOOL b=FALSE;
	DWORD dwRead;

	ReadFile(hFile,&image_dos_header,sizeof(image_dos_header),&dwRead,NULL);
	if(dwRead==sizeof(image_dos_header))
	{
		if(IMAGE_DOS_SIGNATURE==image_dos_header.e_magic)
		{
			if(SetFilePointer(hFile,image_dos_header.e_lfanew,NULL,FILE_BEGIN))
			{
				ReadFile(hFile,&image_nt_headers,sizeof(image_nt_headers),&dwRead,NULL);
				if(dwRead==sizeof(image_nt_headers))
				{
					if(IMAGE_NT_SIGNATURE==image_nt_headers.Signature)
						b=TRUE;
				}
			}
		}
	}
	CloseHandle(hFile);

	return b;
}
