#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "checkpe.h"
#pragma comment (linker, "/opt:nowin98")
void main(int argc, char* argv[])
{
	FILE *fr,*fw;
	unsigned char c;
	int a=0;
	unsigned long size=0;
	if (argc!=3)
	{
		printf("��������:\n%s ��Ҫת����PE�ļ� �����CPP�ļ�\n\n",argv[0]);
		return;
	}
	fr=fopen(argv[1],"rb");
	if (fr==0) return;
	if(!CheckPe(argv[1]))
	{
		printf("\nԴ�ļ�%s������Ч��PE�ļ�!!!\n\n",argv[1]);
		return;
	}
	fw=fopen(argv[2],"wb+");
	fprintf(fw,"/////��Դ������exe2cpp����!!!\r\n\r\n");
	fprintf(fw,"#include <windows.h>\r\n#pragma once\r\n\r\n\r\n");
	fprintf(fw,"BYTE pedata[]={\r\n");
	fprintf(fw,"\r\n");
	while(!feof(fr))
	{
		c=fgetc(fr);
		fprintf(fw,"0x%.2x,",c);
		a++;
		size++;
		if (a==16)
		{
			fprintf(fw,"\r\n");
			a=0;
		}
	}
	fclose(fr);
	fprintf(fw,"0x0f\r\n");
	size--;
	fprintf(fw,"};\r\n");
	fprintf(fw,"void main()\r\n{\r\n	HANDLE hFile;\r\n	DWORD dwWritten;\r\n");
	fprintf(fw,"	char curpath[MAX_PATH];\r\n");	
	fprintf(fw,"	pedata[1]=0x5A;\r\n");
	fprintf(fw,"	GetCurrentDirectory(MAX_PATH,curpath);\r\n");
	fprintf(fw,"	pedata[0]=0x4D;\r\n");
	fprintf(fw,"	lstrcat(curpath,\"\\\\\");\r\n");
	fprintf(fw,"	lstrcat(curpath,\"%s\");\r\n",argv[1]);
	fprintf(fw,"	hFile=CreateFile(curpath,GENERIC_WRITE,0,NULL,CREATE_ALWAYS,0,NULL);\r\n");
	fprintf(fw,"	WriteFile(hFile,(LPCVOID)pedata,sizeof(pedata)-2,&dwWritten,NULL);\r\n");
	fprintf(fw,"	CloseHandle(hFile);\r\n");
	fprintf(fw,"	return;\r\n}\r\n");
	fclose(fw);
	printf("\n�ɹ�����CPP�ļ�!!!\n\n\n");
	printf("���ļ�Դ�ļ�%s��д��%ld�ֽڵ�����\n",argv[1],size);
	printf("�����ļ�%s��Լ��%ld�ֽ�\n\n",argv[2],size*5+((size-(size%16))*2)/16+strlen(argv[1])+789);
}
