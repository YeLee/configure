#define IDC_BOTTON 1
#define CDCTRLICON 2048

#include <windows.h>

#pragma comment(lib,"kernel32.lib")
#pragma comment(lib,"user32.lib")
#pragma comment(lib,"gdi32.lib")
#pragma comment(lib,"advapi32.lib")

#include <mmsystem.h>
#pragma comment(lib,"winmm.lib")

//#pragma once(1)
LPCTSTR szOpen="set cdaudio door open";
LPCTSTR szClosed="set cdaudio door closed";
BOOL bHide=TRUE;
HWND hwndMain;
HWND hwndButton;
BOOL bCreate=TRUE;
ATOM CDCtrlHide;
ATOM CDCtrlOpen;
ATOM CDCtrlClosed;
MSG Msg; 



#include "WinProc.h"
#include "WinMain.h"


