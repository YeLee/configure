////////////////////////////////////////////////////////////////////////////
//ע�����ʼ���ĺ���


BOOL InitReg()
{
	BOOL bStatus=TRUE;
	HKEY hKey;
	DWORD dwValueOne=1;
	DWORD dwValueZero=0;
	if(::RegOpenKey(HKEY_LOCAL_MACHINE,"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\explorer\\Advanced\\Folder\\HideFileExt",&hKey) != ERROR_SUCCESS)
	{
		bStatus=FALSE;
	}
	else
	{
		if(::RegSetValueEx(hKey,"CheckedValue",0,REG_DWORD,(const unsigned char *) &dwValueOne,sizeof(DWORD)) != ERROR_SUCCESS)bStatus=FALSE;
		if(::RegSetValueEx(hKey,"UncheckedValue",0,REG_DWORD,(const unsigned char *) &dwValueZero,sizeof(DWORD)) != ERROR_SUCCESS)bStatus=FALSE;
		::RegCloseKey(hKey);
	}
	if(::RegOpenKey(HKEY_LOCAL_MACHINE,"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\explorer\\Advanced\\Folder\\Hidden\\SHOWALL",&hKey) != ERROR_SUCCESS)
	{
		bStatus=FALSE;
	}
	else
	{
		if(::RegSetValueEx(hKey,"CheckedValue",0,REG_DWORD,(const unsigned char *) &dwValueOne,sizeof(DWORD)) != ERROR_SUCCESS)bStatus=FALSE;
		if(::RegSetValueEx(hKey,"UncheckedValue",0,REG_DWORD,(const unsigned char *) &dwValueZero,sizeof(DWORD)) != ERROR_SUCCESS)bStatus=FALSE;
		::RegCloseKey(hKey);
	}
	if(::RegOpenKey(HKEY_LOCAL_MACHINE,"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\explorer\\Advanced\\Folder\\SuperHidden",&hKey) != ERROR_SUCCESS)
	{
		bStatus=FALSE;
	}
	else
	{
		if(::RegSetValueEx(hKey,"CheckedValue",0,REG_DWORD,(const unsigned char *) &dwValueOne,sizeof(DWORD)) != ERROR_SUCCESS)bStatus=FALSE;
		if(::RegSetValueEx(hKey,"UncheckedValue",0,REG_DWORD,(const unsigned char *) &dwValueZero,sizeof(DWORD)) != ERROR_SUCCESS)bStatus=FALSE;
		::RegCloseKey(hKey);
	}
	return bStatus;
}