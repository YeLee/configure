#include "stdafx.h"
#include "RDwpt.h"
#include "RDwptDlg.h"
#include <Windows.h>

//////////////////////////////////////////////////////////////////
//д��������
int LockRemoveDriver(DWORD RegValue)
{
	HKEY hSub=NULL;
	HKEY hCreate=NULL;
	LPCTSTR SubKey="SYSTEM\\CurrentControlSet\\Control\\StorageDevicePolicies";  
	LPCTSTR CreateKey="SYSTEM\\CurrentControlSet\\Control";  
	LPCTSTR CreateSubKey="StorageDevicePolicies";
	LPCTSTR ValueName="WriteProtect";
	if (RegOpenKeyEx(HKEY_LOCAL_MACHINE,SubKey,0,KEY_ALL_ACCESS,&hSub) != ERROR_SUCCESS)
	{
		RegCloseKey (hSub);
		if (RegValue ==0)
		{
			if (RegOpenKeyEx (HKEY_LOCAL_MACHINE,CreateKey,0,KEY_ALL_ACCESS,&hCreate) != ERROR_SUCCESS)
			{
				RegCloseKey(hCreate);
				return 0;
			}
			else
			{
				RegCloseKey(hCreate);
				return 1;
			}
		}
		if (RegOpenKeyEx (HKEY_LOCAL_MACHINE,CreateKey,0,KEY_ALL_ACCESS,&hCreate) != ERROR_SUCCESS)
		{
			RegCloseKey(hCreate);
			return 0;
		}
		else
		{
			if( RegCreateKey(hCreate,CreateSubKey,&hSub) != ERROR_SUCCESS)
			{
				RegCloseKey(hCreate);
				RegCloseKey(hSub);
				return 0;
			}
			else
				RegCloseKey(hCreate);
		}
	}
	if (RegSetValueEx(hSub,ValueName,0,REG_DWORD,(const unsigned char *)&RegValue,sizeof(RegValue)) != ERROR_SUCCESS)
	{
		RegCloseKey(hSub);
		return 0;
	}
	else
	{
		RegCloseKey(hSub);
		return 1;
	}
}



void CRDwptDlg::OnLock() 
{
	if(LockRemoveDriver(1))
		MessageBox("�ƶ��豸��д�����ɹ�!","��ʾ��",0);
	else
		MessageBox("�ƶ��豸��д����ʧ��!","��ʾ��",0);
}

void CRDwptDlg::OnUnLock() 
{
	if(LockRemoveDriver(0))
		MessageBox("�ƶ��豸��д�����ɹ�!","��ʾ��",0);
	else
		MessageBox("�ƶ��豸��д����ʧ��!","��ʾ��",0);	
}
