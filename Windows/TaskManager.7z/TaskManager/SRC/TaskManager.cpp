#define _UNICODE
#define UNICODE


#include <stdio.h>
#include <windows.h>
#include <tlhelp32.h>
#include <tchar.h>
#include <locale.h>

#include "psapi.h"
#pragma comment(lib,"psapi.lib")

#include "SetPrivilege.h"
#include "ProcessList.h"
#include "ModuleList.h"
#include "TaskKill.h"
#include "Usage.h"


void _tmain ( INT _targc, LPTSTR _targv[] )
{
	::_tsetlocale ( 0, _T ( "chs" ) );

	if ( _targc != 2 )
	{
		usage ( _targv[0] );
		return;
	}

	if ( !SetPrivilege ( SE_DEBUG_NAME ) ) return;

	if ( !SetPrivilege ( SE_INC_BASE_PRIORITY_NAME ) ) return;

	LPTSTR opt;

	if ( * _targv[1] == _T ( '-' ) )
	{
		opt = _targv[1] + 1;

		if ( !*opt )
		{
			usage ( _targv[0] );

		}
		else
		{
			while ( *opt )
			{
				switch ( *opt )
				{
				case _T ( 'p' ) :
					ProcessList();
					break;
				case _T ( 'm' ) :
					ModuleList();
					break;
				case _T ( 'k' ) :
					KillProcess();
					break;
				default:
					usage ( _targv[0] );
					break;
				}

				opt ++;
			}
		}
	}

	return;
}
