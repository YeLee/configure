void ProcessList()
{
	DWORD dwIndex = 0;
	HANDLE hProcess = NULL;
	PROCESSENTRY32 etProcess;
	etProcess.dwSize = sizeof ( PROCESSENTRY32 );
	hProcess = CreateToolhelp32Snapshot ( TH32CS_SNAPPROCESS, 0 );

	if ( hProcess == NULL )
	{
		LPTSTR lpszError = NULL;
		FormatMessage ( FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM, NULL, GetLastError() , MAKELANGID ( LANG_NEUTRAL, SUBLANG_DEFAULT )
		                , ( LPTSTR ) &lpszError, 0, NULL );
		_ftprintf ( stderr, _T ( "[-]%s[-](������Ϊ%ld)\n" ), lpszError, GetLastError() );
		LocalFree ( lpszError );
		return;
	}

	_tprintf ( _T ( "%-s  %-s  %-s  %-s  %-s  %-s\n" ), _T ( "����" ), _T ( "��ǰ����ID" ), _T ( "������ID" ), _T ( "���ȼ�" ), _T ( "�߳���" ), _T ( "������" ) );
	Process32First ( hProcess, &etProcess );

	do
	{
		dwIndex ++;
		_tprintf ( _T ( "%-4ld  %-10ld  %-8ld  %-6ld  %-6ld  %-32s\n" ), dwIndex, etProcess.th32ProcessID, etProcess.th32ParentProcessID, etProcess.pcPriClassBase, etProcess.cntThreads, etProcess.szExeFile );
	}
	while ( Process32Next ( hProcess, &etProcess ) );

	_tprintf ( _T ( "���н���%ld��...\n" ), dwIndex - 1 );

	CloseHandle ( hProcess );
	return;
}
