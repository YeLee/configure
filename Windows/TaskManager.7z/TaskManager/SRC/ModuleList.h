#define BUFFER_LEN 512 //reading buffer for the commandline

VOID GetCmdLine ( HANDLE hProc, TCHAR* pCmdLine, DWORD dwBufLen )
{
	DWORD dwRet = -1;

	DWORD dwAddr = * ( DWORD* ) ( ( DWORD ) GetCommandLine + 1 );//��2���ֽڿ�ʼ��������Ҫ���ĵ�ַ
	TCHAR tcBuf[BUFFER_LEN] = {0};
	DWORD dwRead = 0;

	//�ж�ƽ̨
	DWORD dwVer = GetVersion();

	try
	{
		if ( dwVer < 0x80000000 )   // Windows NT/2000/XP
		{
			if ( ReadProcessMemory ( hProc, ( LPVOID ) dwAddr, &dwAddr, 4, &dwRead ) )
			{
				if ( ReadProcessMemory ( hProc, ( LPVOID ) dwAddr, tcBuf, BUFFER_LEN, &dwRead ) )
				{
					_tcsncpy ( pCmdLine, tcBuf, dwBufLen ); //��ü��һ��dwRead��dwBufLen�Ĵ�С��ʹ�ý�С���Ǹ�
					dwRet = 0;
				}
			}
		}
		else   // Windows 95/98/Me and Win32s
		{

			while ( true )   //ʹ��while��Ϊ�˳���ʱ��������ѭ��
			{
				if ( !ReadProcessMemory ( hProc, ( LPVOID ) dwAddr, &dwAddr, 4, &dwRead ) ) break;

				if ( !ReadProcessMemory ( hProc, ( LPVOID ) dwAddr, &dwAddr, 4, &dwRead ) ) break;

				if ( !ReadProcessMemory ( hProc, ( LPVOID ) ( dwAddr + 0xC0 ), tcBuf, BUFFER_LEN, &dwRead ) ) break;

				if ( *tcBuf == 0 )
				{
					if ( !ReadProcessMemory ( hProc, ( LPVOID ) ( dwAddr + 0x40 ), &dwAddr, 4, &dwRead ) ) break;

					if ( !ReadProcessMemory ( hProc, ( LPVOID ) ( dwAddr + 0x8 ), &dwAddr, 4, &dwRead ) ) break;

					if ( !ReadProcessMemory ( hProc, ( LPVOID ) dwAddr, tcBuf, BUFFER_LEN, &dwRead ) ) break;
				}

				_tcsncpy ( pCmdLine, tcBuf, dwBufLen );//��ü��һ��dwRead��dwBufLen�Ĵ�С��ʹ�ý�С���Ǹ�

				dwRet = 0;
				break;
			}
		}
	}
	catch ( ... )
	{
		dwRet = ERROR_INVALID_ACCESS; //exception
	}

	return;
}

void ModuleList()
{
	HANDLE hProc;
	DWORD dwProcessID;
	_tprintf ( _T ( "[*]��������Ҫ��ѯ��Ϣ�Ľ��̵�PID:" ) );
	_tscanf ( _T ( "%ld" ), &dwProcessID );

	if ( dwProcessID == GetCurrentProcessId() || dwProcessID == 0 )
	{
		_ftprintf ( stderr, _T ( "[-]ϵͳ��ֹ��ѯ��ǰ����\n" ) );
		return;
	}

	hProc = OpenProcess ( PROCESS_ALL_ACCESS, FALSE, dwProcessID );

	if ( hProc == NULL )
	{
		LPTSTR lpszError = NULL;
		FormatMessage ( FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM, NULL, GetLastError() , MAKELANGID ( LANG_NEUTRAL, SUBLANG_DEFAULT )
		                , ( LPTSTR ) &lpszError, 0, NULL );
		_ftprintf ( stderr, _T ( "[-]%s[-](������Ϊ%ld)\n" ), lpszError, GetLastError() );
		LocalFree ( lpszError );
		CloseHandle ( hProc );
		return;
	}

	FILETIME ftCreate;
	FILETIME ftExit;
	FILETIME ftUser;
	FILETIME ftKernel;
	memset ( &ftCreate, 0, sizeof ( FILETIME ) );
	memset ( &ftExit, 0, sizeof ( FILETIME ) );
	memset ( &ftUser, 0, sizeof ( FILETIME ) );
	memset ( &ftKernel, 0, sizeof ( FILETIME ) );
	GetProcessTimes ( hProc, ( LPFILETIME ) &ftCreate, ( LPFILETIME ) &ftExit, ( LPFILETIME ) &ftKernel, ( LPFILETIME ) &ftUser );

	SYSTEMTIME stCreate;
	SYSTEMTIME stExit;
	SYSTEMTIME stUser;
	SYSTEMTIME stKernel;
	FILETIME lftCreate;
	FILETIME lftExit;
	FILETIME lftUser;
	FILETIME lftKernel;

	memset ( &stCreate, 0, sizeof ( SYSTEMTIME ) );
	memset ( &stExit, 0, sizeof ( SYSTEMTIME ) );
	memset ( &stUser, 0, sizeof ( SYSTEMTIME ) );
	memset ( &stKernel, 0, sizeof ( SYSTEMTIME ) );
	memset ( &lftCreate, 0, sizeof ( FILETIME ) );
	memset ( &lftExit, 0, sizeof ( FILETIME ) );
	memset ( &lftUser, 0, sizeof ( FILETIME ) );
	memset ( &lftKernel, 0, sizeof ( FILETIME ) );

	FileTimeToLocalFileTime ( &ftCreate, &lftCreate );
	FileTimeToLocalFileTime ( &ftExit, &lftExit );
	FileTimeToLocalFileTime ( &ftUser, &lftUser );
	FileTimeToLocalFileTime ( &ftKernel, &lftKernel );
	FileTimeToSystemTime ( &lftCreate, &stCreate );
	FileTimeToSystemTime ( &lftExit, &stExit );
	FileTimeToSystemTime ( &lftUser, &stUser );
	FileTimeToSystemTime ( &lftKernel, &stKernel );

	_tprintf ( _T ( "[*]���̴���ʱ��:%4ld��%2ld��%2ld��%2ldʱ%2ld��%2ld��\n" ), stCreate.wYear, stCreate.wMonth, stCreate.wDay, stCreate.wHour, stCreate.wMinute, stCreate.wMinute );
	//	_tprintf(_T("[*]�����˳�ʱ��:%4ld��%2ld��%2ld��%2ldʱ%2ld��%2ld��\n"),stExit.wYear,stExit.wMonth,stExit.wDay,stExit.wHour,stExit.wMinute,stExit.wMinute);
	//	_tprintf(_T("[*]�����û�ʱ��:%4ld��%2ld��%2ld��%2ldʱ%2ld��%2ld��\n"),stUser.wYear,stUser.wMonth,stUser.wDay,stUser.wHour,stUser.wMinute,stUser.wMinute);
	//	_tprintf(_T("[*]�����ں�ʱ��:%4ld��%2ld��%2ld��%2ldʱ%2ld��%2ld��\n"),stKernel.wYear,stKernel.wMonth,stKernel.wDay,stKernel.wHour,stKernel.wMinute,stKernel.wMinute);

	PROCESS_MEMORY_COUNTERS pmcProc;
	pmcProc.cb = sizeof ( PROCESS_MEMORY_COUNTERS );
	GetProcessMemoryInfo ( hProc, &pmcProc, sizeof ( PROCESS_MEMORY_COUNTERS ) );
	_tprintf ( _T ( "%s\t%ld\n%s\t%ldK\n%s\t%ldK\n%s\t%ldK\n%s\t%ldK\n%s\t%ldK\n%s\t%ldK\n%s\t%ldK\n%s\t%ldK\n\n" ),
	           _T ( "[+]��ҳ������Ŀ              " ), pmcProc.PageFaultCount,
	           _T ( "[+]��������(�����ڴ�)�����ֵ" ), pmcProc.PeakWorkingSetSize / 1024,
	           _T ( "[+]��������(�����ڴ�)�Ĵ�С  " ), pmcProc.WorkingSetSize / 1024,
	           _T ( "[+]��ҳ�صķ�ֵ�����ֵ      " ), pmcProc.QuotaPeakPagedPoolUsage / 1024,
	           _T ( "[+]��ҳ�صķ�ֵ��С          " ), pmcProc.QuotaPagedPoolUsage / 1024,
	           _T ( "[+]�Ƿ�ҳ�صķ�ֵ�����ֵ    " ), pmcProc.QuotaPeakNonPagedPoolUsage / 1024,
	           _T ( "[+]�Ƿ�ҳ�صķ�ֵ��С        " ), pmcProc.PagefileUsage / 1024,
	           _T ( "[+]ҳ�ļ�ҳ�Ĵ�С(�����ڴ�)  " ), pmcProc.PagefileUsage / 1024,
	           _T ( "[+]ҳ�ļ�ҳ�����ֵ          " ), pmcProc.PeakPagefileUsage / 1024 );

	TCHAR szProcCl[BUFFER_LEN];
	memset ( szProcCl, 0, sizeof ( TCHAR ) * BUFFER_LEN );
	GetCmdLine ( hProc, szProcCl, BUFFER_LEN );
	CloseHandle ( hProc );
	HANDLE hModule = NULL;
	MODULEENTRY32 etModule;
	memset ( &etModule, 0, sizeof ( MODULEENTRY32 ) );
	etModule.dwSize = sizeof ( MODULEENTRY32 );
	hModule = CreateToolhelp32Snapshot ( TH32CS_SNAPMODULE, dwProcessID );

	if ( hModule != NULL )
	{
		Module32First ( hModule, &etModule );
		_tprintf ( _T ( "[*]����·��:%s\n" ), etModule.szExePath );



		if ( *szProcCl )
		{
			_tprintf ( _T ( "[*]����������:%s\n" ), szProcCl );
			_tprintf ( _T ( "[*]����ǰ���ص�ģ��:\n" ) );

		}
		else
		{
			_ftprintf ( stderr, _T ( "[-]�޷���ȡ����������в���.\n" ) );
		}

		while ( Module32Next ( hModule, &etModule ) )
		{
			_tprintf ( _T ( "\t%s\n" ), etModule.szExePath );
			_tprintf ( _T ( "\t[+]ģ���ַ:%-8lX\tģ���ַ��С:%-8lX\n" ), etModule.modBaseAddr, etModule.modBaseSize );
		}

		CloseHandle ( hModule );
	}
	else
	{
		LPTSTR lpszError = NULL;
		FormatMessage ( FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM, NULL, GetLastError() , MAKELANGID ( LANG_NEUTRAL, SUBLANG_DEFAULT )
		                , ( LPTSTR ) &lpszError, 0, NULL );
		_ftprintf ( stderr, _T ( "[-]%s[-](������Ϊ%ld)\n" ), lpszError, GetLastError() );
		LocalFree ( lpszError );
		_ftprintf ( stderr, _T ( "[-]�޷���ѯ����%ld��ģ����Ϣ...\n" ), dwProcessID );
	}


	return;
}
