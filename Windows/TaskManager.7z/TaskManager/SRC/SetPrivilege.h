
BOOL SetPrivilege ( LPCTSTR PrivilegeValue )
{
	HANDLE HandleProcessToken = NULL;

	if ( !OpenProcessToken ( GetCurrentProcess(), TOKEN_ALL_ACCESS, &HandleProcessToken ) )
	{
		LPTSTR lpszError = NULL;
		FormatMessage ( FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM, NULL, GetLastError() , MAKELANGID ( LANG_NEUTRAL, SUBLANG_DEFAULT )
		                , ( LPTSTR ) &lpszError, 0, NULL );
		_ftprintf ( stderr, _T ( "[-]%s[-](������Ϊ%ld)\n" ), lpszError, GetLastError() );
		LocalFree ( lpszError );
		CloseHandle ( HandleProcessToken );
		return 0;
	}

	TOKEN_PRIVILEGES TokenPrivilege;

	if ( !LookupPrivilegeValue ( NULL, PrivilegeValue, &TokenPrivilege.Privileges[0].Luid ) )
	{
		LPTSTR lpszError = NULL;
		FormatMessage ( FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM, NULL, GetLastError() , MAKELANGID ( LANG_NEUTRAL, SUBLANG_DEFAULT )
		                , ( LPTSTR ) &lpszError, 0, NULL );
		_ftprintf ( stderr, _T ( "[-]%s[-](������Ϊ%ld)\n" ), lpszError, GetLastError() );
		LocalFree ( lpszError );
		CloseHandle ( HandleProcessToken );
		return FALSE;
	}

	TokenPrivilege.PrivilegeCount = 1;
	TokenPrivilege.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
	AdjustTokenPrivileges ( HandleProcessToken, FALSE, &TokenPrivilege, sizeof ( TOKEN_PRIVILEGES ), NULL, NULL );

	if ( GetLastError() != ERROR_SUCCESS )
	{
		LPTSTR lpszError = NULL;
		FormatMessage ( FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM, NULL, GetLastError() , MAKELANGID ( LANG_NEUTRAL, SUBLANG_DEFAULT )
		                , ( LPTSTR ) &lpszError, 0, NULL );
		_ftprintf ( stderr, _T ( "[-]%s[-](������Ϊ%ld)\n" ), lpszError, GetLastError() );
		LocalFree ( lpszError );
		CloseHandle ( HandleProcessToken );
		return FALSE;
	}

	CloseHandle ( HandleProcessToken );
	return TRUE;
}
