void KillProcess()
{
	HANDLE hDstProcess = NULL;
	DWORD dwProcessID;
	_tprintf ( _T ( "[*]��������Ҫ��ֹ�Ľ��̵�PID:" ) );
	_tscanf ( _T ( "%ld" ), &dwProcessID );

	if ( dwProcessID == GetCurrentProcessId() || dwProcessID == 0 )
	{
		_ftprintf ( stderr, _T ( "[-]ϵͳ��ֹ������ǰ����\n" ) );
		return;
	}

	hDstProcess = OpenProcess ( PROCESS_ALL_ACCESS, FALSE, dwProcessID );

	if ( hDstProcess == NULL )
	{
		_tprintf ( _T ( "[-]�򿪽���%ldʧ��\n" ), dwProcessID );
		LPTSTR lpszError = NULL;
		FormatMessage ( FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM, NULL, GetLastError() , MAKELANGID ( LANG_NEUTRAL, SUBLANG_DEFAULT )
		                , ( LPTSTR ) &lpszError, 0, NULL );
		_ftprintf ( stderr, _T ( "[-]%s[-](������Ϊ%ld)\n" ), lpszError, GetLastError() );
		LocalFree ( lpszError );
		CloseHandle ( hDstProcess );
		return;
	}

	if ( ! ( TerminateProcess ( hDstProcess, 1 ) ) )
	{
		_tprintf ( _T ( "[-]�޷���������%ld\n" ), dwProcessID );
		LPTSTR lpszError = NULL;
		FormatMessage ( FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM, NULL, GetLastError() , MAKELANGID ( LANG_NEUTRAL, SUBLANG_DEFAULT )
		                , ( LPTSTR ) &lpszError, 0, NULL );
		_ftprintf ( stderr, _T ( "[-]%s[-](������Ϊ%ld)\n" ), lpszError, GetLastError() );
		LocalFree ( lpszError );
		CloseHandle ( hDstProcess );
		return;
	}

	CloseHandle ( hDstProcess );
	_tprintf ( _T ( "[*]�ɹ���ֹ����%ld\n" ), dwProcessID );
	return;
}
