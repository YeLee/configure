// GetFunAddr.h : main header file for the GETFUNADDR application
//

#if !defined(AFX_GETFUNADDR_H__19AE9CB1_4B8F_4D69_B0DB_4A874AC1572B__INCLUDED_)
#define AFX_GETFUNADDR_H__19AE9CB1_4B8F_4D69_B0DB_4A874AC1572B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CGetFunAddrApp:
// See GetFunAddr.cpp for the implementation of this class
//

class CGetFunAddrApp : public CWinApp
{
public:
	CGetFunAddrApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CGetFunAddrApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CGetFunAddrApp)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GETFUNADDR_H__19AE9CB1_4B8F_4D69_B0DB_4A874AC1572B__INCLUDED_)
