// GetFunAddrDlg.h : header file
//

#if !defined(AFX_GETFUNADDRDLG_H__75640B93_3A39_4EAC_9F0F_FCC5C2EA38A5__INCLUDED_)
#define AFX_GETFUNADDRDLG_H__75640B93_3A39_4EAC_9F0F_FCC5C2EA38A5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CGetFunAddrDlg dialog

class CGetFunAddrDlg : public CDialog
{
// Construction
public:
	CGetFunAddrDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CGetFunAddrDlg)
	enum { IDD = IDD_GETFUNADDR_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CGetFunAddrDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CGetFunAddrDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnGetaddr();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GETFUNADDRDLG_H__75640B93_3A39_4EAC_9F0F_FCC5C2EA38A5__INCLUDED_)
